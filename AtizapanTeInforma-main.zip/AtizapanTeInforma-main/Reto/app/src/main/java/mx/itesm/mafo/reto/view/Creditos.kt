package mx.itesm.mafo.reto.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import mx.itesm.mafo.reto.R

class creditos : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.creditos)

    }
}