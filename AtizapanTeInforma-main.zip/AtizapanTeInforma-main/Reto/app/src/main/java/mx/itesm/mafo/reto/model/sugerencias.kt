package mx.itesm.mafo.reto

class Sugerencias(val tipoSiniestro: String, val sugerencia: String, var expandible: Boolean = false) {
}
