# Atizapan_server
Backend functionality for Atizapan municipality application
